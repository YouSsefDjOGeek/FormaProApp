@extends('layouts.admin.admindashboardtemplate')
@section('pageName')Informations du Centre @endsection


@section('content')



    @if(count($errors)>0)
        <div class="alert alert-danger">
            <span>Informations Non valides :</span>
            <ul>
                @foreach($errors->all() as $error)
                    <li>{{$error}}</li>
                @endforeach
            </ul>
        </div>
    @endif

<section  class="row">
    <h2 class=" dsh-title">Modifier les Informations du centre</h2>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Mettre a jour les informations du centre</strong>
            </div>
            <div class="card-body card-block">
                <form action="{{route('centerInfo')}}" method="post" enctype="multipart/form-data" class="form-horizontal">
                   {{csrf_field()}}

                    <!-- start nom  de centre Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="centerName" class=" form-control-label">Nom du centre</label></div>
                        <div class="col-12 col-md-9"><input  type="text" id="centerName" name="centerName" placeholder="" class="form-control" value="{{ $centerinfo->centerName or ''}}"><small class="form-text text-muted" >Ex : Smart Forma Pro</small></div>
                    </div>
                    <!-- end nom de centre here -->

                    <!-- start Descrpetion de centre  Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="description" class=" form-control-label">Texte de Présentation du centre</label></div>
                        <div class="col-12 col-md-9"><textarea name="description" id="descreption" rows="9" placeholder="" class="form-control">{{ $centerinfo->description or ''}}</textarea><small class="form-text text-muted">Ex : Smart Forma Pro</small></div>
                    </div>
                    <!-- end descreption de centre  here -->


                    <!-- start loi de création    here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="loicreation" class=" form-control-label">Loi de Création</label></div>
                        <div class="col-12 col-md-9"><input type="text" disabled="disabled" id="loicreation"  name="loicreation" placeholder="" value="{{ $centerinfo->loicreation or ''}}" class="form-control"><small class="form-text text-muted">This is a help text</small></div>
                    </div>
                    <!-- end informtions juridiques  here -->
                    <!-- Start email Here  -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="email" class=" form-control-label">Email du centre</label></div>
                        <div class="col-12 col-md-9"><input type="email" id="email" name="email"   value="{{ $centerinfo->email or ''}}" class="form-control"><small class="help-block form-text">Please enter your email</small></div>
                    </div>
                    <!-- End email Here  -->

                    <!-- start Tel Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="phoneNumber" class=" form-control-label">Téléphone</label></div>
                        <div class="col-12 col-md-9"><input type="tel" id="phoneNumber" value="{{ $centerinfo->phoneNumber or ''}}" name="phoneNumber"  class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end Tel Here -->
                    <!-- start Fax Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="fax" class=" form-control-label">Fax</label></div>
                        <div class="col-12 col-md-9"><input type="tel" id="fax" name="fax" value="{{ $centerinfo->fax or ''}}" class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end Fax Here -->
                    <!-- start Working hours Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="workingHours" class=" form-control-label">Horaire de Travail</label></div>
                        <div class="col-12 col-md-9"><input type="tel" id="workingHours" value="{{ $centerinfo->workingHours or ''}}" name="workingHours"  class="form-control"><small class="form-text text-muted">Ex : Lundi à Samedi : 08h:00 jusqu'a 16 |</small></div>
                    </div>
                    <!-- end working Hours Here -->

                    <!-- start Adresse Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="adress" class=" form-control-label">Adresse</label></div>
                        <div class="col-12 col-md-9"><input type="text" id="adress" value="{{$centerinfo->adress or ''}}" name="adress"  class="form-control"><small class="form-text text-muted">Ex : 18 Rue Tahaalabi, Bizerte 7000</small></div>
                    </div>
                    <!-- end Adresse Here -->

                    <!-- start Logitude Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="longitude" class=" form-control-label">Logitude</label></div>
                        <div class="col-12 col-md-9"><input type="text" id="longitude" name="longitude"  value="{{$centerinfo->longitude or ''}}" class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end Logitude Here -->


                    <!-- start latitude Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="latitude" class=" form-control-label">Latitude</label></div>
                        <div class="col-12 col-md-9"><input type="text" value="{{$centerinfo->latitude or ''}}" id="latitude" name="latitude"  class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end latitude Here -->


                    <div style="float: right">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-save"></i> Enregistrer
                        </button>
                        <button type="reset" onclick="location.href='{{"home"}}';" class="btn btn-danger btn-sm">
                                <i class="fa fa-ban"></i>Annuler
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</section>

    @endsection