@extends('layouts.admin.admindashboardtemplate')
@section('pageName') Catalogue des Formations accélérés @endsection
@section('breadcrumb')<li class="active">Liste des formations</li> @endsection
@section('content')


    <section class="dsh-section">
        <div class="row">
            <h2 class="dsh-title">Catalogue des formations</h2>
            <button  class="btn col-lg-3 col-xs-12 hidden-sm btn-primary btn-custom btn-add"
                    onclick="window.location.href='{{route('ajouterFormationAcc')}}'">Ajouter une
                formation
            </button>
        </div>


        <div class="row">
            @foreach($listeFormAcc as $detailForAcc)
                <div class="col-lg-3 col-md-4">
                    <div class="card">
                        <img height="150px" class="card-img-top img-responsive" src="{{"$detailForAcc->picUrl"}}"
                             alt="{{$detailForAcc->picURL}}">
                        <div class="card-body">
                            <h4>Formation : {{$detailForAcc->designation}} </h4>
                            <p class="card-text">
                            <ul class="list-unstyled">
                                <li>Niveau Pré-requis : {{$detailForAcc->niveau}}</li>
                                <li>Durée : {{$detailForAcc->duree}}</li>
                                <li>Prix : {{$detailForAcc->formation_acc_prix}}</li>

                            </ul>
                            <hr>
                            <button type="button" class="btn btn-link"><i class="fa fa-chart-bar"></i> Details</button>
                            <div class="card-facc-icons" style="">
                                <a class="" href="{{route('supprimerFormationAcc',$detailForAcc->id)}}"><i class="fa fa-trash text-danger"></i></a>
                                <a class="" href="{{route('modifierFormationAcc',$detailForAcc->id)}}"><i class="fa fa-edit "></i></a>


                            </div>
                        </div>


                    </div>


                </div>

            @endforeach
        </div>

    </section>
@endsection
