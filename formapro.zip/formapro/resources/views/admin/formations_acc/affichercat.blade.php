@extends('layouts.admin.admindashboardtemplate')
@section('pageName')Details Catégorie : {{$detailCat->designation}} @endsection

@section('title')Ajouter une Catégorie @endsection

@section('content')


    <section class="dsh-section">


        <div class="row">
            <h2 class="dsh-title">Details Catégorie</h2>

            <button style="        margin-top: 19px;
    margin-left: 20px;
    padding: 9px;
    border-radius: 4px;"
                    class=".btn-custom btn-primary btn" onclick="window.location.href='{{route('ajouterCategorie',$detailCat->id)}}'">Ajouter une Catégorie</button>
            <div class="table table-responsive">
                <div class="card-header">
                    <strong class="card-title">Catégorie :  {{$detailCat->designation}}</strong>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <td><strong>#</strong></td>
                                <td>{{$detailCat->id}}</td>
                            </tr>
                            <tr>
                                <td>Designation</td>
                                <td>{{$detailCat->designation}}</td>

                            </tr>
                            <tr>
                                <td>Description</td>
                                <td>{{$detailCat->text}}</td>

                            </tr>
                        <tr>
                            <td>Image</td>
                            <td><img class="img img-responsive" src="{{asset($detailCat->picURL)}}" alt="{{$detailCat->picURL}}"/></td>


                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <div class="float-right btn-group btn-group-margin">
            <button type="button" onclick="window.location.href=' {{route('modifierCategorie',$detailCat->id)}}'" class=" btn btn-primary btn-br4 margin-right20"><i class="fa fa-edit"></i>Modifier</button>

            <button type="button" onclick="window.location.href='{{route('supprimerCategorie',$detailCat->id)}}'" class="btn  btn-danger btn-br4"><i class="fa fa-trash-alt"></i>Supprimer</button>

        </div>

    </section>

    @endsection