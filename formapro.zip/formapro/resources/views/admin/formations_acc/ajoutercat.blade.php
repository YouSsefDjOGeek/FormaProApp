@extends('layouts.admin.admindashboardtemplate')
@section('title')Ajouter une Catégorie @endsection
@section('breadcrumb')<li class="active">Ajouter une Formation</li> @endsection

@section('content')

    <section class="dsh-section">
        <div class="col-lg-12 card">
            <div class="card-header"><h2 class=""> {{isset($detailCat->id) ? "Modifier" : "Ajouter"}} Catégorie</h2></div>
            <div class="card-body card-block">
                <form enctype="multipart/form-data" method="post" action="
        {{isset($detailCat->id) ? route('modifierCategorie',$detailCat->id) : route('ajouterCategorie')}}
                        ">
                    {{csrf_field()}}
                    <div class="form-group">
                        <label for="designation" class=" form-control-label">Désignation</label>
                        <input type="text" value="{{$detailCat->designation or ''}}" name="designation" id="designation" placeholder="" class="form-control">
                    </div>
                    <div class="form-group"><label for="text"  class=" form-control-label">Description</label>
                        <textarea class="form-control" name="text" id="text">{{$detailCat->text or ''}}</textarea>
                        <div class="form-group"><label for="picURL"  class="form-control-label">Photo</label><input
                                    type="file" name="picURL" id="picURL"  value="{{$detailCat->picURL or ''}}" class="form-control"></div>
                        <div style="float: right">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="fa fa-save"></i> Enregistrer
                            </button>
                            <button type="reset" onclick="location.href='{{route('listeCategories')}}';" class="btn btn-danger btn-sm">
                                <i class="fa fa-ban"></i>Annuler
                            </button>
                        </div>
                </form>


            </div>
        </div>


    </section>

@endsection