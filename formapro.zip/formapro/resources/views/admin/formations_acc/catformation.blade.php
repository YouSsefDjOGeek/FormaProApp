@extends('layouts.admin.admindashboardtemplate')
@section('pageTitle')Catalogue des Formations @endsection

@section('content')
    <section class="dsh-section">

        <div class="row">
            <h2 class="dsh-title">Catégories des Formations accélérés</h2>

            <button style="        margin-top: 19px;
    margin-left: 20px;
    padding: 9px;
    border-radius: 4px;"
                    class=".btn-custom btn-primary btn" onclick="window.location.href='{{route('ajouterCategorie')}}'">Ajouter une Catégorie</button>
            <div class="table table-responsive">
                <div class="card-header">
                    <strong class="card-title">Catégories</strong>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Désignation</th>
                            <th scope="col">Formation Affectés</th>
                            <th scope="col">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($listeCatFormation as $cat)
                        <tr>
                            <th scope="row"><a href="">{{$cat->id}}</a> </th>
                            <td>{{$cat->designation}}</td>
                            <td>{{$cat->text}}</td>
                            <td class="icon-edit">
                                <a href="{{route('afficherCategorie',$cat->id)}}"><i class="fa fa-eye"></i></a></a>
                                    <a href="{{route('modifierCategorie',$cat->id)}}">
                                         &nbsp;
                                    <i class="fa fa-edit"></i>
                                    &nbsp;<a href="{{route('supprimerCategorie',$cat->id)}}">
                                        <i class="fa fa-trash-alt"></i></a> </td>
                        </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </section>

@endsection