@extends('layouts.admin.admindashboardtemplate')
@section('pageTitle')Liste des Rendez-vous @endsection

@section('content')
    <section class="dsh-section">
        <div class="row">
            <h2>Liste des Rendez-vous</h2>
        </div>
    </section>


@endsection



