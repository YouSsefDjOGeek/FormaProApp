@extends('layouts.admin.admindashboardtemplate')
@section('pageName')Dashboard @endsection




@section('content')

    <!-- Overview start here -->
    <section  class="row dsh-section">
        <h2 class="dsh-title">Forma Pro</h2>
        <div class="col-sm-12 mb-4">
            <div class="card-group">
                <div class="card col-md-4 sm-6 no-padding card-overview ">
                    <div class="card-body">
                        <div class="h1 text-muted text-right mb-4">
                            <i class="fa fa-users"></i>
                        </div>

                        <div class="h4 mb-0">
                            <small class="count">87500</small>
                        </div>

                        <small class="text-muted small90 font-weight-bold">Total Clients</small>
                        <div class="progress progress-xs mt-3 mb-0 bg-flat-color-1"
                             style="width: 40%; height: 5px;"></div>
                    </div>
                </div>
                <div class="card col-md-4 sm-6 no-padding card-overview">
                    <div class="card-body">
                        <div class="h1 text-muted text-right mb-4">
                            <i class="fa fa-user-plus"></i>
                        </div>
                        <div class="h4 mb-0">
                            <small class="count">385</small>
                        </div>
                        <small class="text-muted small90 font-weight-bold">Nouveau clients</small>
                        <div class="progress progress-xs mt-3 mb-0 bg-flat-color-2"
                             style="width: 40%; height: 5px;"></div>
                    </div>
                </div>
                <div class="card col-md-4 sm-6 no-padding card-overview">
                    <div class="card-body">
                        <div class="h1 text-muted text-right mb-4">
                            <i class="fa fa-cart-plus"></i>
                        </div>
                        <div class="h4 mb-0">
                            <small class="count">1238</small>
                        </div>
                        <small class="text-muted small90 font-weight-bold">Pré-inscris</small>
                        <div class="progress progress-xs mt-3 mb-0 bg-flat-color-3"
                             style="width: 40%; height: 5px;"></div>
                    </div>
                </div>
                <div class="card col-md-4 sm-6 no-padding card-overview">
                    <div class="card-body">
                        <div class="h1 text-muted text-right mb-4">
                            <i class="fa fa-briefcase"></i>
                        </div>
                        <div class="h4 mb-0">
                            <small class="count">28</small>
                        </div>
                        <small class="text-muted small90 font-weight-bold">Formateurs</small>
                        <div class="progress progress-xs mt-3 mb-0 bg-flat-color-4"
                             style="width: 40%; height: 5px;"></div>
                    </div>
                </div>

                <div class="card col-md-4 sm-6 no-padding card-overview">
                    <div class="card-body">
                        <div class="h1 text-muted text-right mb-4">
                            <span class="icon-instrcutor"></span>
                        </div>
                        <div class="h4 mb-0">
                            <small class="count">972</small>
                        </div>
                        <small class="text-muted small90 font-weight-bold">Formations en cours</small>
                        <div class="progress progress-xs mt-3 mb-0 bg-flat-color-1"
                             style="width: 40%; height: 5px;"></div>
                    </div>

                </div>
                <div class="card col-md-4 sm-6 no-padding card-overview">
                    <div class="card-body">
                        <div class="h1 text-muted text-right mb-4">
                            <span class="icon-Meeting_Business bm-overview"></span>
                        </div>
                        <div class="h4 mb-0">6</div>
                        <small class="text-muted small90  font-weight-bold">RDV cette semaine</small>
                        <div class="progress progress-xs mt-3 mb-0 bg-flat-color-5"
                             style="width: 40%; height: 5px;"></div>
                    </div>
                </div>
            </div>

        </div>

    </section>
    <!-- end Overview -->


    <!-- start meeting here -->
    <section class="row dsh-section">
        <div class="col-lg-6 dsh-meeting">
            <h3 class="dsh-title">Evènements et Rendez-vous</h3>
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Rendez-vous aujourd'hui</strong>
                </div>
                <div class="card-body">
                    <table class="table">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Nom</th>
                            <th scope="col">Prénom</th>
                            <th scope="col">Heure</th>
                            <th scope="col">Sujet</th>
                        </tr>

                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>Otto</td>
                            <td>@mdo</td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>Thornton</td>
                            <td>@fat</td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Larry</td>
                            <td>the Bird</td>
                            <td>@twitter</td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Larry</td>
                            <td>the Bird</td>
                            <td>@twitter</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <button class="btn btn-primary">Voir tous</button>
        </div>

        <div class="col-lg-6 calendar">
            <h3 class="dsh-title">Calendrier</h3>
            <!--            <div id='calendar'></div>-->

            <table class="table-condensed table-bordered table-striped">
                <thead>
                <tr>
                    <th colspan="7">
                        <span class="btn-group">
                            <a class="btn"><i class="icon-chevron-left"></i></a>
                        	<a class="btn active">February 2018</a>
                        	<a class="btn"><i class="icon-chevron-right"></i></a>
                        </span>
                    </th>
                </tr>
                <tr>
                    <th>Su</th>
                    <th>Mo</th>
                    <th>Tu</th>
                    <th>We</th>
                    <th>Th</th>
                    <th>Fr</th>
                    <th>Sa</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td class="muted">29</td>
                    <td class="muted">30</td>
                    <td class="muted">31</td>
                    <td>1</td>
                    <td>2</td>
                    <td>3</td>
                    <td>4</td>
                </tr>
                <tr>
                    <td>5</td>
                    <td>6</td>
                    <td>7</td>
                    <td>8</td>
                    <td>9</td>
                    <td>10</td>
                    <td>11</td>
                </tr>
                <tr>
                    <td>12</td>
                    <td>13</td>
                    <td>14</td>
                    <td>15</td>
                    <td>16</td>
                    <td>17</td>
                    <td>18</td>
                </tr>
                <tr>
                    <td>19</td>
                    <td class="btn-primary"><strong>20</strong></td>
                    <td>21</td>
                    <td>22</td>
                    <td>23</td>
                    <td>24</td>
                    <td>25</td>
                </tr>
                <tr>
                    <td>26</td>
                    <td>27</td>
                    <td>28</td>
                    <td>29</td>
                    <td class="muted">1</td>
                    <td class="muted">2</td>
                    <td class="muted">3</td>
                </tr>
                </tbody>
            </table>

        </div>

    </section>

    <!-- paper request here -->

    <section class="row dsh-section">

        <div class="col-lg-6">
            <h3 class="dsh-title">Service scolarité</h3>
            <div class="card">
                <div class="card-header">
                    <strong class="card-title">Demande Papiers</strong>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">First</th>
                            <th scope="col">Last</th>
                            <th scope="col">Type</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td>Mark</td>
                            <td>Otto</td>
                            <td>Attestation de présence</td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td>Jacob</td>
                            <td>Thornton</td>
                            <td>Attestation de présence</td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td>Larry</td>
                            <td>the Bird</td>
                            <td>Demande de stage</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <button class="btn btn-primary">Voir tous</button>
        </div>

        <!-- Paiement -->

        <div class="col-lg-6">
            <h3 class="dsh-title">Paiement</h3>
            <div class="col-lg-6 col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="clearfix">
                            <i class="fa fa-cogs bg-flat-color-5 p-3 font-2xl mr-3 float-left text-light"></i>
                            <div class="h5 text-secondary mb-0 mt-1">49</div>
                            <div class="text-muted text-uppercase font-weight-bold font-xs small">Clients Pré-inscris</div>
                        </div>
                        <div class="b-b-1 pt-3"></div>
                        <hr>
                        <div class="more-info pt-2" style="margin-bottom:-10px;">
                            <a class="font-weight-bold font-xs btn-block text-muted small" href="#">Voir Détails <i class="fa fa-angle-right float-right font-lg"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class=" col-lg-6 col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="clearfix">
                            <i class="fa fa-cogs bg-flat-color-5 p-3 font-2xl mr-3 float-left text-light"></i>
                            <div class="h5 text-secondary mb-0 mt-1">TND 4.999,50</div>
                            <div class="text-muted text-uppercase font-weight-bold font-xs small">Total Payé cette mois</div>
                        </div>
                        <div class="b-b-1 pt-3"></div>
                        <hr>
                        <div class="more-info pt-2" style="margin-bottom:-10px;">
                            <a class="font-weight-bold font-xs btn-block text-muted small" href="#">Voir Détails <i class="fa fa-angle-right float-right font-lg"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="clearfix">
                            <i class="fa fa-cogs bg-flat-color-5 p-3 font-2xl mr-3 float-left text-light"></i>
                            <div class="h5 text-secondary mb-0 mt-1"> 4999,50 TND</div>
                            <div class="text-muted text-uppercase font-weight-bold font-xs small">Montant a Payer</div>
                        </div>
                        <div class="b-b-1 pt-3"></div>
                        <hr>
                        <div class="more-info pt-2" style="margin-bottom:-10px;">
                            <a class="font-weight-bold font-xs btn-block text-muted small" href="#">Voir Détails <i class="fa fa-angle-right float-right font-lg"></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-3">
                <div class="card">
                    <div class="card-body">
                        <div class="clearfix">
                            <i class="fa fa-cogs bg-flat-color-5 p-3 font-2xl mr-3 float-left text-light"></i>
                            <div class="h5 text-secondary mb-0 mt-1">TND 4.999,50</div>
                            <div class="text-muted text-uppercase font-weight-bold font-xs small">Clients en attende</div>
                        </div>
                        <div class="b-b-1 pt-3"></div>
                        <hr>
                        <div class="more-info pt-2" style="margin-bottom:-10px;">
                            <a class="font-weight-bold font-xs btn-block text-muted small" href="#">Voir Détails <i class="fa fa-angle-right float-right font-lg"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div> <!-- paiement widgets -->







    </section><!-- end content here -->
    <section class="row dsh-section app-stats">


        <div class="col-lg-6">

            <h3>Statstiques</h3>

            <div class="col-lg-8">


            </div>
            <div class
            <div class="card">
                <div class="card-body">
                    <h4 class="mb-3">Line Chart</h4>
                    <div class="flot-container">
                        <div id="chart1" style="width:100%;height:275px;"></div>
                    </div>
                </div>
            </div><!-- /# card -->
        </div><!-- /# column -->
        <!--
        <div class="margin-top20 col-lg-6">

            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-money text-success border-success"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Total Profit</div>
                                <div class="stat-digit">1,012</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- widget 2 -->
        <!--
            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-user text-primary border-primary"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">New Customer</div>
                                <div class="stat-digit">961</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- widget 3 -->
        <!--

            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-layout-grid2 text-warning border-warning"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Active Projects</div>
                                <div class="stat-digit">770</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- widget 4 -->
        <!--

            <div class="col-lg-6 col-md-6">
                <div class="card">
                    <div class="card-body">
                        <div class="stat-widget-one">
                            <div class="stat-icon dib"><i class="ti-link text-danger border-danger"></i></div>
                            <div class="stat-content dib">
                                <div class="stat-text">Referrals</div>
                                <div class="stat-digit">2,781</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- end widget 4 here -->



        </div><!-- end widgets -->



    </section><!-- end stats section -->




    </div> <!-- end content here -->



@endsection