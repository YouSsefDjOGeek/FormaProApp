<aside id="left-panel" class="left-panel">
    <nav class="navbar navbar-expand-sm navbar-default">

        <div class="navbar-header">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu"
                    aria-controls="main-menu" aria-expanded="false" aria-label="Afficher le Menu">
                <i class="fa fa-bars"></i>
            </button>
            <a class="navbar-brand" href="{{route('home')}}"><img src="{{asset('images/logo.png')}}" alt="Logo"></a>
            <a class="navbar-brand hidden" href="{{route('home')}}"><span>FPro</span></a>
        </div>

        <div id="main-menu" class="main-menu collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li class="active">
                    <a href="{{route('home')}}"> <i class="menu-icon fa fa-tachometer-alt"></i>Tableau de Board </a>
                </li>


                <h3 class="menu-title">Scolarité</h3><!-- /.menu-title -->

                <!--                    <li class="menu-item-has-children dropdown">-->
                <!--                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="false" aria-expanded="false"> <i class="menu-icon fa fa-laptop"></i>Apropos</a>-->
                <!--                        <ul class="sub-menu children dropdown-menu">-->
                <!--                            <li><i class="fa fa-puzzle-piece"></i><a href="ui-buttons.html">Présentation</a></li>-->
                <!--                            <li><i class="fa fa-id-badge"></i><a href="ui-badges.html">Informations Juridiques</a></li>-->
                <!--                            <li><i class="fa fa-id-badge"></i><a href="ui-badges.html">Coordonées de contact</a></li>-->
                <!--                        </ul>-->
                <!--                    </li>-->
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"> <i class="menu-icon fa fa-users"></i>Utilisateurs/Clients</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="fa fa-graduation-cap"></i><a href="tables-basic.html">Clients</a></li>
                        <li><i class="fa fa-briefcase"></i></span><a href="tables-data.html">Formateurs</a></li>
                        <li><i class="fa fa-users"></i><a href="tables-data.html">Administrateurs</a></li>
                    </ul>
                <li class="">
                    <a href="index.php"> <i class="menu-icon fa fa-comments"></i>Messagerie <span
                                class="badge badge-danger">5</span></a>
                </li>
                </li>

                <!-- Activités -->
                <h3 class="menu-title">Activités</h3><!-- /.menu-title -->

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"> <span class="icon-Meeting_Business">

                    </span>Rendez-vous<span class="badge badge-danger">6</span></a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-users"></i><a href="{{route('calendar')}}">Calendier</a></li>
                        <li><i class="menu-icon fa fa-users"></i><a href="{{route('listerdv')}}">Liste des rendez-vous</a>
                        </li>
                        <li><i class="menu-icon far fa-calendar-plus"></i><a href="{{route('ajouterrdv')}}">Plannifier un
                                rendez-vous</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"> <i class="menu-icon fa fa-money-bill-alt"></i>Paiements</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-fort-awesome"></i><a href="font-fontawesome.html">Liste des
                                paiements</a></li>
                        <li><i class="menu-icon ti-themify-logo"></i><a href="font-themify.html">Effectuer Un
                                paiement</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"> <i class="menu-icon fa fa-calendar-alt
"></i>Evènements</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><i class="menu-icon fa fa-fort-awesome"></i><a href="font-fontawesome.html">Liste des
                                Evènement</a></li>
                        <li><i class="menu-icon ti-themify-logo"></i><a href="font-themify.html">Plannifier un
                                Evènement</a></li>
                    </ul>
                </li>

                <!-- Formations -->
                <h3 class="menu-title">Formations</h3><!-- /.menu-title -->

                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"><i class="fa fa-book menu-icon"></i> Formations accélérées</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><a href="{{route(('listeformationsAcc'))}}">Catalogue</a></li>
                        <li><a href="{{route('listeCategories')}}">Catégories</a>
                        </li>
                        <li><a href="#">Pré-inscription</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"><i class="fa fa-book menu-icon"></i> Formation diplômante</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><a href="#">BTP</a></li>
                        <li><a href="#">BTS</a></li>
                        <li><a href="#">CAP</a></li>
                        <li><a href="#">Pré-inscription</a></li>
                    </ul>
                </li>
                <li class="menu-item-has-children dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true"
                       aria-expanded="false"> <i class="menu-icon fa fa-thumbs-up"></i>Feedback Formations</a>
                    <ul class="sub-menu children dropdown-menu">
                        <li><a href="#">Avis</a></li>
                        <li><a href="#">Propositions</a></li>
                    </ul>
                </li>



                <h3 class="menu-title">Paramètres</h3><!-- /.menu-title -->
                <li class="">
                    <a href="{{route('centerInfo')}}"> <i class="menu-icon fa fa-building"></i>Informations du centre
                    </a>
                </li>
                <li class="">
                    <a href="{{route('centerInfo')}}"> <i class="menu-icon fa fa-sliders-h"></i>Paramètres de L'application
                    </a>
                </li>
                <li class="margin-top20">
                    <a id="menuToggle" href="#"> <i class="menu-icon fa fa-arrow-circle-left"></i>Réduire le menu </a>
                </li>
            </ul>
        </div><!-- /.navbar-collapse -->
    </nav>
</aside><!-- /#left-panel -->