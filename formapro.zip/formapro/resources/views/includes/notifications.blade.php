@if (Session::has('added'))
    <section class="row">

        <div class="content mt-3">


            <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <small class="badge badge-pill badge-success">Success</small>
                    {{Session::get('added')}}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <small aria-hidden="true">&times;</small>
                    </button>
                </div>
            </div>


        </div>
    </section>
@endif
<!-- End Add Notification -->

<!-- Start  Update Notification -->

@if (Session::has('deleted'))
    <section class="row">

        <div class="content mt-3">

            <div class="col-sm-12">
                <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                    <small class="badge badge-pill badge-danger">Removed</small>
                    {{Session::get('updated')}}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <small aria-hidden="true">&times;</small>
                    </button>
                </div>
            </div>


        </div><!-- end notifications here -->


    </section>
@endif
@if (Session::has('updated'))
    <section class="row">

        <div class="content mt-3">

            <div class="col-sm-12">
                <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                    <small class="badge badge-pill badge-danger">Removed</small>
                    {{Session::get('updated')}}
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <small aria-hidden="true">&times;</small>
                    </button>
                </div>
            </div>


        </div><!-- end notifications here -->


    </section>
@endif

@if (count($errors)>0)
    <section class="row">

        <div class="content mt-3">
            <!-- notifications here -->


            <div class="col-sm-12">

                @foreach($errors->all() as $error)
                    <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                        <small class="badge badge-pill badge-danger">Erreur</small>
                        {{$error}}
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <small aria-hidden="true">&times;</small>
                        </button>
                    </div>
                @endforeach
            </div>


        </div><!-- end notifications here -->


    </section>
@endif