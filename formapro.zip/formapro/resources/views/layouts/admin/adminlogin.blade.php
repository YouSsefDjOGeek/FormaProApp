<!DOCTYPE html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html lang="{{ app()->getLocale() }}"><!--<![endif]-->
<!-- Include Head Tag ( Require CSS Files -->
<head>
    @include('includes.head')
    <title>@yield('pageName')</title>

</head>

<body  class="bg-dark">
@yield('content')
<!-- start footer section+ JS Files here -->
@include('includes.footer')
</body>
</html>
