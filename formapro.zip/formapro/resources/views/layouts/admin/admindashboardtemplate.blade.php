<!DOCTYPE html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html lang="{{ app()->getLocale() }}"><!--<![endif]-->
<!-- Include Head Tag ( Require CSS Files -->
<head>
    @include('includes.head')
    @yield('css')
    <title>@yield('pageName')</title>
</head>

<body>

<!-- Include Aside here s-->
@include('includes.navbar')
<!-- Content here -->
<div id=" right-panel" class="content right-panel">
@include('includes.header')
@include('includes.breadcrumb')
    @include('includes.notifications')
    <!-- notifications here -->
    <!--Start Add Notification -->

    @yield('content')


</div>
<!-- start footer section+ JS Files here -->
    @include('includes.footer')
</body>
</html>


