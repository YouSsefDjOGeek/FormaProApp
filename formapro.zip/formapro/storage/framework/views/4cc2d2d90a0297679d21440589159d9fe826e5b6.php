<?php $__env->startSection('pageTitle'); ?>Liste des Rendez-vous <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="dsh-section">
        <div class="row">
            <h2>Liste des Rendez-vous</h2>
        </div>
    </section>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>