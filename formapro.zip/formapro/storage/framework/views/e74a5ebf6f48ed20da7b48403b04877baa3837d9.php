<?php $__env->startSection('pageName'); ?>Informations du Centre <?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>



    <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <span>Informations Non valides :</span>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<section  class="row">
    <h2 class=" dsh-title">Modifier les Informations du centre</h2>
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Mettre a jour les informations du centre</strong>
            </div>
            <div class="card-body card-block">
                <form action="<?php echo e(route('centerInfo')); ?>" method="post" enctype="multipart/form-data" class="form-horizontal">
                   <?php echo e(csrf_field()); ?>


                    <!-- start nom  de centre Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="centerName" class=" form-control-label">Nom du centre</label></div>
                        <div class="col-12 col-md-9"><input  type="text" id="centerName" name="centerName" placeholder="" class="form-control" value="<?php echo e(isset($centerinfo->centerName) ? $centerinfo->centerName : ''); ?>"><small class="form-text text-muted" >Ex : Smart Forma Pro</small></div>
                    </div>
                    <!-- end nom de centre here -->

                    <!-- start Descrpetion de centre  Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="description" class=" form-control-label">Texte de Présentation du centre</label></div>
                        <div class="col-12 col-md-9"><textarea name="description" id="descreption" rows="9" placeholder="" class="form-control"><?php echo e(isset($centerinfo->description) ? $centerinfo->description : ''); ?></textarea><small class="form-text text-muted">Ex : Smart Forma Pro</small></div>
                    </div>
                    <!-- end descreption de centre  here -->


                    <!-- start loi de création    here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="loicreation" class=" form-control-label">Loi de Création</label></div>
                        <div class="col-12 col-md-9"><input type="text" disabled="disabled" id="loicreation"  name="loicreation" placeholder="" value="<?php echo e(isset($centerinfo->loicreation) ? $centerinfo->loicreation : ''); ?>" class="form-control"><small class="form-text text-muted">This is a help text</small></div>
                    </div>
                    <!-- end informtions juridiques  here -->
                    <!-- Start email Here  -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="email" class=" form-control-label">Email du centre</label></div>
                        <div class="col-12 col-md-9"><input type="email" id="email" name="email"   value="<?php echo e(isset($centerinfo->email) ? $centerinfo->email : ''); ?>" class="form-control"><small class="help-block form-text">Please enter your email</small></div>
                    </div>
                    <!-- End email Here  -->

                    <!-- start Tel Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="phoneNumber" class=" form-control-label">Téléphone</label></div>
                        <div class="col-12 col-md-9"><input type="tel" id="phoneNumber" value="<?php echo e(isset($centerinfo->phoneNumber) ? $centerinfo->phoneNumber : ''); ?>" name="phoneNumber"  class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end Tel Here -->
                    <!-- start Fax Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="fax" class=" form-control-label">Fax</label></div>
                        <div class="col-12 col-md-9"><input type="tel" id="fax" name="fax" value="<?php echo e(isset($centerinfo->fax) ? $centerinfo->fax : ''); ?>" class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end Fax Here -->
                    <!-- start Working hours Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="workingHours" class=" form-control-label">Horaire de Travail</label></div>
                        <div class="col-12 col-md-9"><input type="tel" id="workingHours" value="<?php echo e(isset($centerinfo->workingHours) ? $centerinfo->workingHours : ''); ?>" name="workingHours"  class="form-control"><small class="form-text text-muted">Ex : Lundi à Samedi : 08h:00 jusqu'a 16 |</small></div>
                    </div>
                    <!-- end working Hours Here -->

                    <!-- start Adresse Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="adress" class=" form-control-label">Adresse</label></div>
                        <div class="col-12 col-md-9"><input type="text" id="adress" value="<?php echo e(isset($centerinfo->adress) ? $centerinfo->adress : ''); ?>" name="adress"  class="form-control"><small class="form-text text-muted">Ex : 18 Rue Tahaalabi, Bizerte 7000</small></div>
                    </div>
                    <!-- end Adresse Here -->

                    <!-- start Logitude Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="longitude" class=" form-control-label">Logitude</label></div>
                        <div class="col-12 col-md-9"><input type="text" id="longitude" name="longitude"  value="<?php echo e(isset($centerinfo->longitude) ? $centerinfo->longitude : ''); ?>" class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end Logitude Here -->


                    <!-- start latitude Here -->
                    <div class="row form-group">
                        <div class="col col-md-3"><label for="latitude" class=" form-control-label">Latitude</label></div>
                        <div class="col-12 col-md-9"><input type="text" value="<?php echo e(isset($centerinfo->latitude) ? $centerinfo->latitude : ''); ?>" id="latitude" name="latitude"  class="form-control"><small class="form-text text-muted">Ex : 70 000 000</small></div>
                    </div>
                    <!-- end latitude Here -->


                    <div style="float: right">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-save"></i> Enregistrer
                        </button>
                        <button type="reset" onclick="location.href='<?php echo e("home"); ?>';" class="btn btn-danger btn-sm">
                                <i class="fa fa-ban"></i>Annuler
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>