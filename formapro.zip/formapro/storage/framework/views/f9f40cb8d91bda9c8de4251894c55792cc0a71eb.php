<?php $__env->startSection('pageTitle'); ?>Catalogue des Formations <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="dsh-section">

        <div class="row">
            <h2 class="dsh-title">Catégories des Formations accélérés</h2>

            <button style="        margin-top: 19px;
    margin-left: 20px;
    padding: 9px;
    border-radius: 4px;"
                    class=".btn-custom btn-primary btn" onclick="window.location.href='<?php echo e(route('ajouterCategorie')); ?>'">Ajouter une Catégorie</button>
            <div class="table table-responsive">
                <div class="card-header">
                    <strong class="card-title">Catégories</strong>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <thead>
                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Désignation</th>
                            <th scope="col">Formation Affectés</th>
                            <th scope="col">Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $listeCatFormation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th scope="row"><a href=""><?php echo e($cat->id); ?></a> </th>
                            <td><?php echo e($cat->designation); ?></td>
                            <td><?php echo e($cat->text); ?></td>
                            <td class="icon-edit">
                                <a href="<?php echo e(route('afficherCategorie',$cat->id)); ?>"><i class="fa fa-eye"></i></a></a>
                                    <a href="<?php echo e(route('modifierCategorie',$cat->id)); ?>">
                                         &nbsp;
                                    <i class="fa fa-edit"></i>
                                    &nbsp;<a href="<?php echo e(route('supprimerCategorie',$cat->id)); ?>">
                                        <i class="fa fa-trash-alt"></i></a> </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>