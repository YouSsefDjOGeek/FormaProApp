<?php $__env->startSection('pageName'); ?>FormaproApp Authentification <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
    <div class="sufee-login d-flex align-content-center flex-wrap">
        <div class="container">
            <div class="login-content">
                <div class="login-logo">
                    <a href="http://formapro-bizerte.tn">
                        <img class="align-content" src="<?php echo e(asset('images/logo.png')); ?>" alt="Smart Forma Pro">
                    </a>
                </div>
                <div class="login-form">
                    <form action="<?php echo e(route('login')); ?>" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="form-group" <?php echo e($errors->has('email') ? ' has-error' : ''); ?>>
                            <label>Identifiant</label>
                            <input id="email" type="email" class="form-control" name="email" value="<?php echo e(old('email')); ?>" required autofocus>
                            <?php if($errors->has('email')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group <?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                            <label>Mot de passe</label>
                            <input id="password" type="password" class="form-control" name="password" required>
                        </div>
                        <div class="checkbox">
                            <label>
                                <input type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                            </label>

                            <?php if($errors->has('password')): ?>
                                <span class="help-block">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                            <?php endif; ?>

                            <label class="pull-right">
                                <a href="<?php echo e(route('password.request')); ?>">Mot de passe oblié?</a>

                            </label>

                        </div>
                        <button type="submit" class="btn btn-success btn-flat m-b-30 m-t-30">Se Connecter</button>

                        <div class="social-login-content">
                            <div class="social-button">
                                <button type="button" class="btn social facebook btn-flat btn-addon mb-3"><i class="ti-facebook"></i>Sign in with facebook
                                </button>
                                <button type="button" class="btn social twitter btn-flat btn-addon mt-2"><i class="ti-twitter"></i>Sign in with twitter</button>
                            </div>
                        </div>
                        <div class="register-link m-t-15 text-center">
                            <p>Don't have account ? <a href="#"> Sign Up Here</a></p>
                        </div>
                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <div class="checkbox">
                                    <label>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin.adminlogin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>