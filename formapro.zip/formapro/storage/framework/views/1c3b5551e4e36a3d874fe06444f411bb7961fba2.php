<?php $__env->startSection('pageName'); ?>Details Catégorie : <?php echo e($detailCat->designation); ?> <?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>Ajouter une Catégorie <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <section class="dsh-section">


        <div class="row">
            <h2 class="dsh-title">Details Catégorie</h2>

            <button style="        margin-top: 19px;
    margin-left: 20px;
    padding: 9px;
    border-radius: 4px;"
                    class=".btn-custom btn-primary btn" onclick="window.location.href='<?php echo e(route('ajouterCategorie',$detailCat->id)); ?>'">Ajouter une Catégorie</button>
            <div class="table table-responsive">
                <div class="card-header">
                    <strong class="card-title">Catégorie :  <?php echo e($detailCat->designation); ?></strong>
                </div>
                <div class="card-body">
                    <table class="table table-striped">
                        <tbody>
                            <tr>
                                <td><strong>#</strong></td>
                                <td><?php echo e($detailCat->id); ?></td>
                            </tr>
                            <tr>
                                <td>Designation</td>
                                <td><?php echo e($detailCat->designation); ?></td>

                            </tr>
                            <tr>
                                <td>Description</td>
                                <td><?php echo e($detailCat->text); ?></td>

                            </tr>
                        <tr>
                            <td>Image</td>
                            <td><img class="img img-responsive" src="<?php echo e(asset($detailCat->picURL)); ?>" alt="<?php echo e($detailCat->picURL); ?>"/></td>


                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
        <div class="float-right btn-group btn-group-margin">
            <button type="button" onclick="window.location.href=' <?php echo e(route('modifierCategorie',$detailCat->id)); ?>'" class=" btn btn-primary btn-br4 margin-right20"><i class="fa fa-edit"></i>Modifier</button>

            <button type="button" onclick="window.location.href='<?php echo e(route('supprimerCategorie',$detailCat->id)); ?>'" class="btn  btn-danger btn-br4"><i class="fa fa-trash-alt"></i>Supprimer</button>

        </div>

    </section>

    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>