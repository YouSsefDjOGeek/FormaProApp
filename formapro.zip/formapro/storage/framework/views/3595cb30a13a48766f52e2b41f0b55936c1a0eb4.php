<?php $__env->startSection('pageName'); ?> Catalogue des Formations accélérés <?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?><li class="active">Liste des formations</li> <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <section class="dsh-section">
        <div class="row">
            <h2 class="dsh-title">Catalogue des formations</h2>
            <button  class="btn col-lg-3 col-xs-12 hidden-sm btn-primary btn-custom btn-add"
                    onclick="window.location.href='<?php echo e(route('ajouterFormationAcc')); ?>'">Ajouter une
                formation
            </button>
        </div>


        <div class="row">
            <?php $__currentLoopData = $listeFormAcc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailForAcc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3 col-md-4">
                    <div class="card">
                        <img height="150px" class="card-img-top img-responsive" src="<?php echo e("$detailForAcc->picUrl"); ?>"
                             alt="<?php echo e($detailForAcc->picURL); ?>">
                        <div class="card-body">
                            <h4>Formation : <?php echo e($detailForAcc->designation); ?> </h4>
                            <p class="card-text">
                            <ul class="list-unstyled">
                                <li>Niveau Pré-requis : <?php echo e($detailForAcc->niveau); ?></li>
                                <li>Durée : <?php echo e($detailForAcc->duree); ?></li>
                                <li>Prix : <?php echo e($detailForAcc->formation_acc_prix); ?></li>

                            </ul>
                            <hr>
                            <button type="button" class="btn btn-link"><i class="fa fa-chart-bar"></i> Details</button>
                            <div class="card-facc-icons" style="">
                                <a class="" href="<?php echo e(route('supprimerFormationAcc',$detailForAcc->id)); ?>"><i class="fa fa-trash text-danger"></i></a>
                                <a class="" href="<?php echo e(route('modifierFormationAcc',$detailForAcc->id)); ?>"><i class="fa fa-edit "></i></a>


                            </div>
                        </div>


                    </div>


                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>