<!DOCTYPE html>
<!--[if lt IE 7]>
<html class="no-js lt-ie9 lt-ie8 lt-ie7" lang=""> <![endif]-->
<!--[if IE 7]>
<html class="no-js lt-ie9 lt-ie8" lang=""> <![endif]-->
<!--[if IE 8]>
<html class="no-js lt-ie9" lang=""> <![endif]-->
<!--[if gt IE 8]><!-->
<html lang="<?php echo e(app()->getLocale()); ?>"><!--<![endif]-->
<!-- Include Head Tag ( Require CSS Files -->
<head>
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <title><?php echo $__env->yieldContent('pageName'); ?></title>

</head>

<body  class="bg-dark">
<?php echo $__env->yieldContent('content'); ?>
<!-- start footer section+ JS Files here -->
<?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</body>
</html>
