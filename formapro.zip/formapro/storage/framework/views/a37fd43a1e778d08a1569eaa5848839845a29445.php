<?php if(Session::has('added')): ?>
    <section class="row">

        <div class="content mt-3">


            <div class="col-sm-12">
                <div class="alert  alert-success alert-dismissible fade show" role="alert">
                    <small class="badge badge-pill badge-success">Success</small>
                    <?php echo e(Session::get('added')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <small aria-hidden="true">&times;</small>
                    </button>
                </div>
            </div>


        </div>
    </section>
<?php endif; ?>
<!-- End Add Notification -->

<!-- Start  Update Notification -->

<?php if(Session::has('deleted')): ?>
    <section class="row">

        <div class="content mt-3">

            <div class="col-sm-12">
                <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                    <small class="badge badge-pill badge-danger">Removed</small>
                    <?php echo e(Session::get('updated')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <small aria-hidden="true">&times;</small>
                    </button>
                </div>
            </div>


        </div><!-- end notifications here -->


    </section>
<?php endif; ?>
<?php if(Session::has('updated')): ?>
    <section class="row">

        <div class="content mt-3">

            <div class="col-sm-12">
                <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                    <small class="badge badge-pill badge-danger">Removed</small>
                    <?php echo e(Session::get('updated')); ?>

                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <small aria-hidden="true">&times;</small>
                    </button>
                </div>
            </div>


        </div><!-- end notifications here -->


    </section>
<?php endif; ?>

<?php if(count($errors)>0): ?>
    <section class="row">

        <div class="content mt-3">
            <!-- notifications here -->


            <div class="col-sm-12">

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="alert  alert-danger alert-dismissible fade show" role="alert">
                        <small class="badge badge-pill badge-danger">Erreur</small>
                        <?php echo e($error); ?>

                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                            <small aria-hidden="true">&times;</small>
                        </button>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>


        </div><!-- end notifications here -->


    </section>
<?php endif; ?>