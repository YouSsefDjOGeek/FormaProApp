<?php $__env->startSection('title'); ?>Ajouter une Catégorie <?php $__env->stopSection(); ?>
<?php $__env->startSection('breadcrumb'); ?><li class="active">Ajouter une Formation</li> <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <section class="dsh-section">
        <div class="col-lg-12 card">
            <div class="card-header"><h2 class=""> <?php echo e(isset($detailCat->id) ? "Modifier" : "Ajouter"); ?> Catégorie</h2></div>
            <div class="card-body card-block">
                <form enctype="multipart/form-data" method="post" action="
        <?php echo e(isset($detailCat->id) ? route('modifierCategorie',$detailCat->id) : route('ajouterCategorie')); ?>

                        ">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="designation" class=" form-control-label">Désignation</label>
                        <input type="text" value="<?php echo e(isset($detailCat->designation) ? $detailCat->designation : ''); ?>" name="designation" id="designation" placeholder="" class="form-control">
                    </div>
                    <div class="form-group"><label for="text"  class=" form-control-label">Description</label>
                        <textarea class="form-control" name="text" id="text"><?php echo e(isset($detailCat->text) ? $detailCat->text : ''); ?></textarea>
                        <div class="form-group"><label for="picURL"  class="form-control-label">Photo</label><input
                                    type="file" name="picURL" id="picURL"  value="<?php echo e(isset($detailCat->picURL) ? $detailCat->picURL : ''); ?>" class="form-control"></div>
                        <div style="float: right">
                            <button type="submit" class="btn btn-primary btn-sm">
                                <i class="fa fa-save"></i> Enregistrer
                            </button>
                            <button type="reset" onclick="location.href='<?php echo e(route('listeCategories')); ?>';" class="btn btn-danger btn-sm">
                                <i class="fa fa-ban"></i>Annuler
                            </button>
                        </div>
                </form>


            </div>
        </div>


    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>