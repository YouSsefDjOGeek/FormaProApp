<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Tableau de Board</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('home')); ?>">Dashboard</a></li>
                    <?php echo $__env->yieldContent('breadcrumb'); ?>
                </ol>
            </div>
        </div>
    </div>
</div>