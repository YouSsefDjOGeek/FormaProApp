<?php $__env->startSection('pageTitle'); ?>Plannifier un Rendez Vous <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="dsh-section">
        <div class="col-lg-12 card">

            <div class="card-header"><h2 class=""> Plannifier un Rendez-vous </h2></div>
            <div class="card-body card-block">
                <form  method="post" action="<?php echo e(route('ajouterrdv')); ?>">
                <?php echo e(csrf_field()); ?>

                    <!-- Titre -->
                    <div class="form-group">
                        <label for="titre" class=" form-control-label">Titre</label>
                        <input type="text" value="" name="titre" id="titre" placeholder="" class="form-control">
                    </div>
                    <!-- designation -->
                    <div class="form-group">
                        <label for="remarqueRDV" class=" form-control-label">Details</label>
                        <textarea class="form-control" name="remarqueRDV" id="remarqueRDV"></textarea>
                    </div>
                    <!-- designation -->

                    <!-- Date -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="dateRDV" class="form-control-label">Date Rendez-vous</label>

                            <div class="input-group">

                                <input id="dateRDV" name="dateRDV" type="date" class="form-control col-sm-8" value="" data-val="true" autocomplete="off">
                                <div class="input-group-addon">
                                    <span data-toggle="popover" data-container="body" data-html="true" data-title="Security Code" data-content="<div class='text-center one-card'>The 3 digit code on back of the card..<div class='visa-mc-cvc-preview'></div></div>" data-trigger="hover"><i class="fa fa-calendar"></i> </span>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="formation_acc_prix" class="form-control-label">Heure Rendez-vous</label>

                            <div class="input-group">

                                <input id="heureRDV" name="heureRDV" type="time" class="form-control col-sm-8" value="" data-val="true" data-val-required="Please enter the security code" data-val-cc-cvc="Please enter a valid security code" autocomplete="off">
                                <div class="input-group-addon">
                                    <span data-toggle="popover" data-container="body" data-html="true" data-title="Security Code" data-content="<div class='text-center one-card'>The 3 digit code on back of the card..<div class='visa-mc-cvc-preview'></div></div>" data-trigger="hover"><i class="fa fa-clock"></i> </span>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Niveau -->

                    <div class="form-group">
                        <label>Priorité</label>
                        <select name="catFormation" class="form-control-sm form-control">

                            <option value="18">Normale</option>
                            <option value="19">Important</option>
                            <option value="19">Urgent</option>

                        </select>


                    </div>
                    <div class="form-group">
                        <label for="niveau" class=" form-control-label">niveau Pré-requis</label>
                        <input type="text" value="" name="niveau" id="niveau" placeholder="" class="form-control">
                    </div>




                    <!-- Image Formation -->
                    <div class="form-group">
                        <label for="picURL" class="form-control-label">Photo</label>
                        <input type="file" name="picURL" id="picURL" value="" class="form-control"></div>
                    <div style="float: right">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-save"></i> Enregistrer
                        </button>
                        <button type="reset" onclick="location.href='http://localhost:8000/catalogue-formation';" class="btn btn-danger btn-sm">
                            <i class="fa fa-ban"></i>Annuler
                        </button>
                    </div>
                </form>


            </div>
        </div>
    </section>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>