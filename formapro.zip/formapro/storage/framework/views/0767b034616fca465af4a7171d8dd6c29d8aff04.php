<HR/>

<footer class="footer">FormaPro Application &copy 2018
    <?php if(!Auth::guest()): ?>

    <div class="user">
        <a class="user" href="<?php echo e(route('logout')); ?>"
           onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
            Logout
        </a>
    </div>

<?php endif; ?>
    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
        <?php echo e(csrf_field()); ?>

    </form>
</footer>
<!-- import script files -->
<script src="<?php echo e(asset('js/vendor/jquery-2.1.4.min.js')); ?>"></script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/html5shiv/3.7.3/html5shiv.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.3/umd/popper.min.js"></script>
<script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/chart-js/Chart.bundle.js')); ?>"></script>
<script src="<?php echo e(asset('js/dashboard.js')); ?>"></script>
<script src="<?php echo e(asset('js/widgets.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/vector-map/jquery.vmap.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/vector-map/jquery.vmap.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/lib/vector-map/jquery.vmap.sampledata.js')); ?>"></script>
<script src="<?php echo e(asset('/js/lib/vector-map/country/jquery.vmap.world.js')); ?>"></script>

