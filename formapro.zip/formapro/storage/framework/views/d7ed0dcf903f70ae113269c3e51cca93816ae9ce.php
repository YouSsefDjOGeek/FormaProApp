<?php $__env->startSection('pageName'); ?><?php echo e(isset($detailsForAcc->id) ?"Modifier" : "Ajouter"); ?> une Formation accéléré <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="dsh-section">
        <div class="col-lg-12 card">

            <div class="card-header"><h2 class=""> <?php echo e(isset($detailsForAcc->id) ? "Modifier" : "Ajouter"); ?> une Formation
                    Accéléré</h2></div>
            <div class="card-body card-block">
                <form enctype="multipart/form-data" method="post" action="<?php echo e(isset($detailsForAcc->id) ? route('modifierFormationAcc',$detailsForAcc->id) : route('ajouterFormationAcc')); ?>">
                <?php echo e(csrf_field()); ?>

                <!-- designation -->
                    <div class="form-group">
                        <label for="designation" class=" form-control-label">Désignation</label>
                        <input type="text" value="<?php echo e(isset($detailsForAcc->designation) ? $detailsForAcc->designation : ''); ?>" name="designation"
                               id="designation" placeholder="" class="form-control">
                    </div>
                    <!-- designation -->
                    <div class="form-group">
                        <label for="text" class=" form-control-label">Description</label>
                        <textarea class="form-control" name="text" id="text"><?php echo e(isset($detailsForAcc->text) ? $detailsForAcc->text : ''); ?></textarea>
                    </div>
                    <!-- designation -->

                    <!-- Durée -->
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="duree" class="form-control-label">Volume Horaire</label>

                            <div class="input-group">

                                <input id="duree" name="duree" type="number" class="form-control col-sm-8"
                                       value="<?php echo e(isset($detailsForAcc->duree) ? $detailsForAcc->duree : ''); ?>"
                                       data-val="true" autocomplete="off">
                                <div class="input-group-addon">
                                    <span data-toggle="popover" data-container="body" data-html="true"
                                          data-title="Security Code"
                                          data-content="<div class='text-center one-card'>The 3 digit code on back of the card..<div class='visa-mc-cvc-preview'></div></div>"
                                          data-trigger="hover">Hr</span>
                                </div>
                            </div>

                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="formation_acc_prix" class="form-control-label">Prix</label>

                            <div class="input-group">

                                <input id="formation_acc_prix" name="formation_acc_prix" type="number"
                                       class="form-control col-sm-8"
                                       value="<?php echo e(isset($detailsForAcc->formation_acc_prix) ? $detailsForAcc->formation_acc_prix : ''); ?>" data-val="true"
                                       data-val-required="Please enter the security code"
                                       data-val-cc-cvc="Please enter a valid security code" autocomplete="off">
                                <div class="input-group-addon">
                                    <span data-toggle="popover" data-container="body" data-html="true"
                                          data-title="Security Code"
                                          data-content="<div class='text-center one-card'>The 3 digit code on back of the card..<div class='visa-mc-cvc-preview'></div></div>"
                                          data-trigger="hover">TND</span>
                                </div>
                            </div>

                        </div>
                    </div>

                    <!-- Niveau -->
                    <div class="form-group">
                        <label for="niveau" class=" form-control-label">niveau Pré-requis</label>
                        <input type="text" value="<?php echo e(isset($detailsForAcc->designation) ? $detailsForAcc->designation : ''); ?>" name="niveau" id="niveau"
                               placeholder="" class="form-control">
                    </div>

                    <div class="form-group">
                        <label>Catégorie Formation</label>
                        <select name="catFormation" class="form-control-sm form-control">

                            <?php $__currentLoopData = $listeCatFormation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catFormation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($catFormation->id); ?>"><?php echo e($catFormation->designation); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>


                    </div>


                    <!-- Image Formation -->
                    <div class="form-group">
                        <label for="picURL" class="form-control-label">Photo</label>
                        <input type="file" name="picURL" id="picURL" value="<?php echo e(isset($detailsForAcc->picURL) ? $detailsForAcc->picURL : ''); ?>"
                               class="form-control"></div>
                    <div style="float: right">
                        <button type="submit" class="btn btn-primary btn-sm">
                            <i class="fa fa-save"></i> Enregistrer
                        </button>
                        <button type="reset" onclick="location.href='<?php echo e(route('listeformationsAcc')); ?>';"
                                class="btn btn-danger btn-sm">
                            <i class="fa fa-ban"></i>Annuler
                        </button>
                    </div>
                </form>


            </div>
        </div>


    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.admindashboardtemplate', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>