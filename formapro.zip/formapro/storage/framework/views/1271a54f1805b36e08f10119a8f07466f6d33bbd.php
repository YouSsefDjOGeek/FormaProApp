
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="FormaPro Admin Application">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="<?php echo e(asset('images/icon.ico')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset("images/icon.ico")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/normalize.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome-all.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/flag-icon.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/cs-skin-elastic.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/formapro-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('scss/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/fw.css')); ?>">

    


    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

<?php echo $__env->yieldContent('css'); ?>