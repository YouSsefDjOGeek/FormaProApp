<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateRdvTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('rdvs', function (Blueprint $table) {
            //
            $table->increments('idRDV');
            $table->string('titre');
            $table->date('dateRDV');
            $table->time('heureRDV');
            $table->string('priorityRDV');
            $table->string('personne');
            $table->text('remarqueRDV')->nullable();
            $table->timestamp('createdAt');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('rdvs', function (Blueprint $table) {
            //
            Schema::dropIfExists('rdvs');
        });
    }
}
