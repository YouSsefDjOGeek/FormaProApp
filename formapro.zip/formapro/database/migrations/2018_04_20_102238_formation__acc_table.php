<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class FormationAccTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create('Formations_accs', function (Blueprint $table) {
            $table->increments('id');
            $table->string('designation')->unique();
            $table->text('text')->nullable();
            $table->string('picUrl')->nullable();
            $table->double('formation_acc_prix');
            $table->string('niveau');
            $table->string('duree');
            $table->integer('catFormation')->unsigned();
            $table->timestamps();
            //--- Foreign key
            $table->foreign('catFormation')->references('id')->on('formation_ac_cats')->onDelete('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
        Schema::dropIfExists('Formations_accs');

        Schema::dropIfExists('formation_ac_cats');
    }
}
