<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CenterInfo extends Model
{
    //
    protected $table = 'centerinfos';
    protected $fillable = [
        'centerName', 'description', 'phoneNumber','fax','email','loicreation',
        'adress','workingHours','longitude','latitude'
    ];


}
