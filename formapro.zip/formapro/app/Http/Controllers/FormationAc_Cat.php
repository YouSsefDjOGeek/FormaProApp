<?php

namespace App\Http\Controllers;

use App\Formationaccats;
use App\Formationaccs;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;



class FormationAc_Cat extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    // Liste des catégories : Formation accélérés
    public function listeCategories() {

        $listeCatFormation = Formationaccats::all();
        return view('admin.formations_acc.catformation')->with('listeCatFormation',$listeCatFormation);

    }


    //--- Afficher details Catégorie

    public function afficherCategorie($id) {
        $detailCat = Formationaccats::findOrFail($id);
        return view('admin.formations_acc.affichercat')->with('detailCat',$detailCat);
    }

    public function ajouterCategorie (Request $request) {
        // Only Exectuted on post


        if ($request->isMethod('post')) {
            //--- Data validation
            $this->validate($request,[
                'designation'=>'required|unique:formation_ac_cats',
                'text'=>'required'

            ]);

            //---- Saving data
            $param = $request->except('_token');
            $nvcat = new Formationaccats();
            $nvcat->designation=$param['designation'];
            $nvcat->text=$param['text'];

            //--- Dealing with Uploaded Images

            if($request->hasFile('picURL')){
                $picURL = $request->file('picURL');
                $fileName = time().'_'.$picURL->getClientOriginalName();

                Image::make($picURL)->save(public_path('images/uploads/').$fileName);
                $imgFullPath='images/uploads/'.$fileName;
                $nvcat->picURL=$imgFullPath;

            }
            else $nvcat->picURL= 'noimg.jpg';


            $nvcat->save();
            return redirect('categorie-formation')->with('added', 'Catégorie ajouté avec succès');

        }

        return view('admin.formations_acc.ajoutercat');
    }


    public function supprimerCategorie ($id) {

        $detailCat = Formationaccats::findOrFail($id);
        $detailCat->delete();
        return redirect('categorie-formation')->with('removed', 'Catégorie supprimé avec succès');

    }

    public function modifierCategorie (Request $request,$id) {
        $detailCat = Formationaccats::findOrFail($id);

        if ($request->isMethod('post')) {


            //--- Data validation
            $this->validate($request,[
                'designation'=>'required',
                'text'=>'required'
            ]);

            $param = $request->except('_token');
            $detailCat->designation=$param['designation'];
            $detailCat->text=$param['text'];

            //--- Dealing with images
            if($request->hasFile('picURL')){
                $picURL = $request->file('picURL');
                $fileName = time().'_'.$picURL->getClientOriginalName();
                Image::make($picURL)->save(public_path('images/uploads/').$fileName);
                $imgFullPath='images/uploads/'.$fileName;
                $detailCat->picURL=$imgFullPath;
            }

            $detailCat->save();
            return redirect('categorie-formation')->with('updated', 'Catégorie modifié avec succès');

        }
        return view('admin.formations_acc.ajoutercat')->with('detailCat',$detailCat);

    }


}
