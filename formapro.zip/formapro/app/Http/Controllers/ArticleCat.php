<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ArticleCat extends Controller
{
    //
}
