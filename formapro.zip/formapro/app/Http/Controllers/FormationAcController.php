<?php

namespace App\Http\Controllers;

use App\Formationaccats;
use App\Formationaccs;
use Illuminate\Http\Request;
use Intervention\Image\Facades\Image;

class FormationAcController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    //
    public function listeformationsAcc()
    {
        $listeFormAcc = Formationaccs::all();
        return view('admin.formations_acc.listeformations')->with('listeFormAcc',$listeFormAcc);
    }
    public function ajouterFormationAcc(Request $request) {


        if ($request->isMethod('post')) {

            //----- Validate Inputs
            $this->validate($request, [
                'designation' => 'required|unique:formations_accs',
                'formation_acc_prix' => 'required|max:4|min:2',
                'niveau' => 'required',
                'duree' => 'required',
                'catFormation' => 'required',
            ]);
            //--- Passing values to Model Instance

            $param = $request->except('_token');
            $nvFormationAcc = new Formationaccs();
            $nvFormationAcc->designation = $param['designation'];
            $nvFormationAcc->text = $param['text'];
            $nvFormationAcc->formation_acc_prix = $param['formation_acc_prix'];
            $nvFormationAcc->duree =$param['duree'];
            $nvFormationAcc->niveau = $param['niveau'];
            $nvFormationAcc->catFormation = $param['catFormation'];
            //--- Dealing with Uploaded Images

            if($request->hasFile('picURL')){
                $picURL = $request->file('picURL');
                $fileName = time().'_'.$picURL->getClientOriginalName();

                Image::make($picURL)->save(public_path('images/uploads/').$fileName);
                $imgFullPath='images/uploads/'.$fileName;
                $nvFormationAcc->picURL=$imgFullPath;

            }
            else $nvFormationAcc->picURL= 'noimg.jpg';

            //--- Storing values into the database
            $nvFormationAcc->save();

            return redirect('catalogue-formation')->with('added', 'Formation accéléré ajouté avec success !');


        }

        // Get Method
        $listeCatFormation = Formationaccats::all();
        return view('admin.formations_acc.ajouterFormationAcc')->with('listeCatFormation',$listeCatFormation);



    }

    //-------- Supprimer Formation

    public function supprimerFormationAcc($id) {

        $formationAcc = Formationaccs::findOrFail($id);
        $formationAcc->delete();
        return redirect('catalogue-formation')->with('removed', 'Formation Accéléré supprimé avec succès');

    }

    public function afficherFormationAcc ($id) {
        $formationAcc = Formationaccs::findOrFail($id);
        return view('admin.formations_acc.afficherforAcc')->with('formationAcc',$formationAcc);
    }


    //----- Modifier Formation Accéléré


    public function modifierFormationAcc (Request $request,$id) {
        $formationAcc = Formationaccs::findOrFail($id);

        if ($request->isMethod('post')) {
            //----- Validate Inputs
            $this->validate($request, [
                'designation' => 'required',
                'formation_acc_prix' => 'required|max:4|min:2',
                'niveau' => 'required',
                'duree' => 'required',
                'catFormation' => 'required',
            ]);
            //--- Passing values to Model Instance
            $param = $request->except('_token');
            $formationAcc ->designation = $param['designation'];
            $formationAcc->text = $param['text'];
            $formationAcc->formation_acc_prix = $param['formation_acc_prix'];
            $formationAcc->duree= $param['duree'];
            $formationAcc->niveau = $param['niveau'];
            $formationAcc->catFormation = $param['catFormation'];
            if (isset($request['picURL'])){
                $formationAcc->picURL = $param['picURL'];
            }
            else $formationAcc->picURL = 'noimg.jpg';
            //--- Storing values into the database
            dd($formationAcc);
            $formationAcc->save();
            return redirect('catalogue-formation')->with('updated', 'Formation accéléré modifié avec success !');
        }
        // Get Method
        $listeCatFormation = Formationaccats::all();

        return view('admin.formations_acc.ajouterFormationAcc',array(
            'listeCatFormation'=>$listeCatFormation,
            'detailsForAcc'=>$formationAcc
        ));
    }
}
