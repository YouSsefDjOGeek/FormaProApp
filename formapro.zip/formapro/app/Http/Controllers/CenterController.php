<?php

namespace App\Http\Controllers;

use App\CenterInfo;
use Illuminate\Http\Request;

class CenterController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    //
    public function updateCenterInfo(Request $request) {
        $centerInfo = CenterInfo::find(1);
        if ($request->isMethod('post')) {
            // validate data
            $this->validate($request,[
                    'centerName'=>'required',
                    'description' => 'required',
                    'phoneNumber' => 'required',
                    'fax' => 'required',
                    'email' => 'required',
                    'workingHours' => 'required',
                    'longitude' => 'required',
                    'latitude' => 'required'
                ]

            );

            //--- Recieving values

            $centerInfo->centerName = $request->input('centerName');
            $centerInfo->description = $request->input('description');
            $centerInfo->phoneNumber = $request->input('phoneNumber');
            $centerInfo->fax = $request->input('fax');
            $centerInfo->email = $request->input('email');
            $centerInfo->adress = $request->input('adress');
            $centerInfo->workingHours = $request->input('workingHours');
            $centerInfo->longitude = $request->input('longitude');
            $centerInfo->latitude = $request->input('latitude');

            //--- Store values in the database
            $centerInfo->save();



        }


        return view('admin.centerinfo')->with('centerinfo',$centerInfo);


    }


}
