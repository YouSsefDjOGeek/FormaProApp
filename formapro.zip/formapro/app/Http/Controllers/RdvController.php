<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RdvController extends Controller
{
    //
    public function listeRDV() {
        return view('admin.rdv.listerdv');
    }
    //----
    public function afficherCalendrier() {
        return view('admin.rdv.calendar');
    }

    public function plannifierRDV () {


    }

    public function detailsRDV() {

    }

    public function ajouterrdv (Request $request) {



        //----- Return View
    return view('admin.rdv.ajouterrdv');
    }
}
