<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Formationaccs extends Model
{
    //
    public $table="formations_accs";
    public function Formationaccats () {
        return $this->hasOne('App\Formationaccats');

    }
}
