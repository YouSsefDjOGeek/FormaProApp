<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Formationaccats extends Model
{
    //
    public $table="formation_ac_cats";
    protected $fillable = ['desination','text','photoURL'];
    public function Formationaccs () {
        return $this->belongsTo('App\Formationaccs');
    }
}
