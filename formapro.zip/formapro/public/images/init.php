<?php
/**
 * Created by PhpStorm.
 * User: Youssef
 * Date: 08-Mar-18
 * Time: 10:22 AM
 */

$AppName = 'FormaPro WebApp';
