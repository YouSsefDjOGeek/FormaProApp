<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/





/*** Home Page Route **/

Route::get('/', 'HomeController@index')->name('home');
Route::get('/home', 'HomeController@index')->name('home');

/** Paramètres générales du centre */



Route::get('/centerinfo', 'CenterController@updateCenterInfo')->name('centerInfo');;

Route::post('/centerinfo', 'CenterController@updateCenterInfo')->name('centerInfo');

//-----------------------------

/**  Catalogue des Formation */

Route::get('/catalogue-formation','FormationAcController@listeformationsAcc')->name('listeformationsAcc');
Route::get('/catalogue-formation/ajouter','FormationAcController@ajouterFormationAcc')->name('ajouterFormationAcc');
Route::post('/catalogue-formation/ajouter','FormationAcController@ajouterFormationAcc')->name('ajouterFormationAcc');
Route::get('/catalogue-formation/supprimer/{id}','FormationAcController@supprimerFormationAcc')->name('supprimerFormationAcc');
Route::get('/catalogue-formation/modifier/{id}','FormationAcController@modifierFormationAcc')->name('modifierFormationAcc');
Route::post('/catalogue-formation/modifier/{id}','FormationAcController@modifierFormationAcc')->name('modifierFormationAcc');
Route::get('/catalogue-formation/{id}','FormationAcController@supprimerFormationAcc')->name('afficherFormationAcc');


//--------------------------
/**  Catégories des formations accélérés   **/

/*** Affichage toutes les catégories **/
/** Form ajout catégorie */
Route::get('/categorie-formation/ajouter','FormationAc_Cat@ajouterCategorie')->name('ajouterCategorie');
/** Action :  ajout catégorie **/
Route::post('/categorie-formation/ajouter/','FormationAc_Cat@ajouterCategorie')->name('ajouterCategorie');
Route::get('/categorie-formation','FormationAc_Cat@listeCategories')->name('listeCategories');
/*** Afficher details catégories **/
Route::get('/categorie-formation/{id}','FormationAc_Cat@afficherCategorie')->name('afficherCategorie');
/*** Supp Catégorie **/
Route::get('/categorie-formation/supprimer/{id}','FormationAc_Cat@supprimerCategorie')->name('supprimerCategorie');
/******** Modifier Cat Form**/
Route::get('/categorie-formation/modifier/{id}','FormationAc_Cat@modifierCategorie')->name('modifierCategorie');
/******* Action : Modifier Categorie **/
Route::post('/categorie-formation/modifier/{id}','FormationAc_Cat@modifierCategorie')->name('modifierCategorie');


Auth::routes();

//--------------------------
/**  Rendez-vous   **/
//--------------------------
Route::get('/rdv/calendar','RdvController@afficherCalendrier')->name('calendar');
Route::get('/rdv/listerdv','RdvController@listerdv')->name('listerdv');
Route::get('/rdv/ajouterrdv','RdvController@ajouterrdv')->name('ajouterrdv');
